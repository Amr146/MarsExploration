//This file is for testing the DS only(will be deleted once we start working in the program)
#include<iostream>
#include "MarsStation.h"
using namespace std;

int main()
{
	MarsStation station;	
	station.Simulate();
	system("pause");
	return 0;
}