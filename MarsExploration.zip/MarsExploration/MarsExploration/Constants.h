#pragma once
enum class MissionType {
	E,
	P,
	M
};